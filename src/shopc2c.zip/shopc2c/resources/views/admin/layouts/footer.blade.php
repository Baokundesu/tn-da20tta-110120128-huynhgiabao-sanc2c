

  <!-- Main Footer -->
  <footer class="main-footer" style="background-color: #333; color: #ffffff; position: absolute; bottom: 0; width: 100%;">
    <div class="float-left">
      <strong>Copyright &copy; 2024 .</strong>
      All rights reserved.
    </div>
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 0.0.1
    </div>
  </footer>
  <!-- /.main-footer -->
</div>
<!-- ./wrapper -->


