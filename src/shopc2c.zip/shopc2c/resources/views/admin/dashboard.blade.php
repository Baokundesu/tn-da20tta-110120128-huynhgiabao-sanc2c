@extends('admin.layout')

@section('title', 'Dashboard')

@section('content')
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <h1 class="m-0 text-dark">Dashboard</h1>
        </div>
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Your content here -->
            <p>Content of your dashboard goes here.</p>
        </div>
    </section>
    <!-- /.content -->
@endsection
