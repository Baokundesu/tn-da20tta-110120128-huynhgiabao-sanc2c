<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Giỏ hàng của bạn</h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($cartItems->isEmpty()): ?>
        <p>Giỏ hàng của bạn hiện đang trống.</p>
    <?php else: ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Sản phẩm</th>
                    <th>Giá</th>
                    <th>Số lượng</th>
                    <th>Thành tiền</th>
                    <th>Hành động</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->store->product_name); ?></td>
                        <td><?php echo e($item->price); ?></td>
                        <td><?php echo e($item->quantity); ?></td>
                        <td><?php echo e($item->price * $item->quantity); ?></td>
                        <td>
                            <form action="<?php echo e(route('cart.update', ['store' => $item->store_id])); ?>" method="POST" style="display:inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <input type="number" name="quantity" value="<?php echo e($item->quantity); ?>" min="1" style="width: 60px;">
                                <button type="submit" class="btn btn-primary btn-sm">Cập nhật</button>
                            </form>
                            <form action="<?php echo e(route('cart.delete', ['store' => $item->store_id])); ?>" method="POST" style="display:inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">Xóa</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php
            $totalPrice = $cartItems->sum(function($item) {
                return $item->price * $item->quantity;
            });
        ?>
        <div class="d-flex justify-content-between align-items-center">
            <form action="<?php echo e(route('cart.clear')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-warning">Xóa toàn bộ giỏ hàng</button>
            </form>
            <h4>Tổng tiền: <?php echo e($totalPrice); ?> đồng</h4>
        </div>
        <div class="d-flex justify-content-end mt-3">
            <form action="<?php echo e(route('cart.showCheckout')); ?>" method="GET">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-success">Thanh toán</button>
            </form>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shopc2c\resources\views/cart/index.blade.php ENDPATH**/ ?>