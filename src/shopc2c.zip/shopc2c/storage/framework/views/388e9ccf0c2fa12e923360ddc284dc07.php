<?php $__env->startSection('title', 'Đăng ký gian hàng'); ?>

<?php $__env->startSection('content'); ?>
<div class="container" style="width: 80%; max-width: 800px; margin: 0 auto;">
    <h1 class="mb-4">Đăng ký gian hàng</h1>

    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('shop.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        
        <h2>Thông tin chi tiết</h2>
        <div class="form-group">
            <label for="type">Loại hàng</label>
            <select id="type" name="type" class="form-control">
                <option value="rau_cuu_qua">Rau củ quả</option>
                <option value="trai_cay">Trái cây</option>
                <option value="dua_muoi">Dưa muối</option>
                <option value="lua_gao">Lúa gạo</option>
            </select>
        </div>
        
        <div class="form-group">
            <label for="origin">Xuất xứ</label>
            <input type="text" id="origin" name="origin" class="form-control">
        </div>
        
        <div class="form-group">
            <div>
                <input type="checkbox" id="free" name="is_free" value="1" onclick="togglePriceField()">
                <label for="free">Tôi muốn cho tặng miễn phí</label>
            </div>
        </div>
        
        <div class="form-group">
            <label for="price">Giá bán (VNĐ)</label>
            <input type="number" id="price" name="price" class="form-control">
        </div>

        <div class="form-group">
            <label for="unit">Đơn vị tính</label>
            <div>
                <input type="checkbox" id="kg" name="unit" value="kg"> <label for="kg">kg</label>
                <input type="checkbox" id="trai" name="unit" value="trai"> <label for="trai">Trái</label>
                <input type="checkbox" id="cu" name="unit" value="cu"> <label for="cu">Củ</label>
                <input type="checkbox" id="chuc" name="unit" value="chuc"> <label for="chuc">Chục</label>
            </div>
        </div>
        
        <div class="form-group">
            <label for="address">Địa chỉ chi tiết</label>
            <input type="text" id="address" name="address" class="form-control" required>
        </div>

        <hr>

        <h2>Tiêu đề đăng tin</h2>
        <div class="form-group">
            <label for="name">Tiêu đề đăng tin</label>
            <input type="text" id="name" name="name" class="form-control" required>
        </div>
        
        <div class="form-group">
            <label for="description">Mô tả chi tiết sản phẩm</label>
            <textarea id="description" name="description" class="form-control" required></textarea>
        </div>
        
        <button type="submit" class="btn btn-primary">Đăng ký</button>
    </form>
</div>

<script>
    function togglePriceField() {
        var freeCheckbox = document.getElementById("free");
        var priceField = document.getElementById("price");
        
        if (freeCheckbox.checked) {
            priceField.setAttribute("disabled", true);
        } else {
            priceField.removeAttribute("disabled");
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shopc2c\resources\views/shop/create.blade.php ENDPATH**/ ?>