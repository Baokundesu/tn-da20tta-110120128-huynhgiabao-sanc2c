<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng ký tài khoản</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap icons-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/register.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .form-register {
            width: 100%;
            max-width: 400px;
            padding: 15px;
            margin: auto;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            margin-top: 50px;
            margin-bottom: 50px;
        }
        .form-register .form-group label {
            text-align: left;
        }
        .form-register .btn-primary {
            background-color: #1977cc;
            border-color: #1977cc;
        }
        .form-register .btn-primary:hover {
            background-color: #135995;
            border-color: #135995;
        }
    </style>
</head>
<body class="text-center">
    <form class="form-register">
        <img class="mb-4" src="assets/logo.png" alt="" width="72" height="72">
        <h1 class="h3 mb-3 font-weight-normal">Đăng ký tài khoản</h1>
        <div class="form-group text-left">
            <label for="inputName">Họ và tên</label>
            <input type="text" id="inputName" class="form-control" placeholder="Nhập họ và tên" required autofocus>
        </div>
        <div class="form-group text-left">
            <label for="inputEmail">Email</label>
            <input type="email" id="inputEmail" class="form-control" placeholder="Nhập email" required>
        </div>
        <div class="form-group text-left">
            <label for="inputPassword">Mật khẩu</label>
            <input type="password" id="inputPassword" class="form-control" placeholder="Nhập mật khẩu" required>
        </div>
        <div class="form-group text-left">
            <label for="confirmPassword">Xác nhận mật khẩu</label>
            <input type="password" id="confirmPassword" class="form-control" placeholder="Nhập lại mật khẩu" required>
        </div>
        <button class="btn btn-lg btn-primary btn-block" type="submit">Đăng ký</button>
        <p class="mt-5 mb-3 text-muted">&copy; 2024</p>
    </form>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\shopc2c\resources\views/auths\register.blade.php ENDPATH**/ ?>