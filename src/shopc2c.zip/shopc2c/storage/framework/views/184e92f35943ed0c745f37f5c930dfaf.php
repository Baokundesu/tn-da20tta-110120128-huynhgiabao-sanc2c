<?php $__env->startSection('content'); ?>
<div class="container text-center">
    <div class="alert alert-success">
        <h1>Đặt hàng thành công!</h1>
        <i class="fa fa-check-circle" style="font-size: 5em; color: green;"></i>
        <p>Cảm ơn bạn đã đặt hàng. Chúng tôi sẽ xử lý đơn hàng của bạn sớm nhất.</p>
        <a href="<?php echo e(route('home')); ?>" class="btn btn-primary mt-3">Quay lại trang chủ</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shopc2c\resources\views/cart/success.blade.php ENDPATH**/ ?>