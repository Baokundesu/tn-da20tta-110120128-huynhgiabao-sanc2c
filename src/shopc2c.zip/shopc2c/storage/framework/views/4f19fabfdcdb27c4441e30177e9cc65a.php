<?php $__env->startSection('title', 'Quản lý tất cả các gian hàng'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col">
            <h2>Danh sách tất cả các gian hàng</h2>
        </div>
    </div>
    <div class="table-responsive mt-4">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Tên gian hàng</th>
                    <th>Người đăng</th>
                    <th>Địa chỉ</th>
                    <th>Thao tác</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($store->id); ?></td>
                        <td><?php echo e($store->title); ?></td>
                        <td><?php echo e($store->user->name); ?></td>
                        <td><?php echo e($store->address); ?></td>
                        <td>
                            <form action="<?php echo e(route('admin.stores.delete', $store->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Bạn có chắc chắn muốn xóa gian hàng này không?')">Xóa</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shopc2c\resources\views/admin/posts.blade.php ENDPATH**/ ?>