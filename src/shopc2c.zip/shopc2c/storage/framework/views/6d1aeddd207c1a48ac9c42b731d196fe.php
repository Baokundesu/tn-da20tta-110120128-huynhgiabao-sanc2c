<?php $__env->startSection('title', 'Chi tiết sản phẩm'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row">
        <div class="col-md-6">
            <?php if($store->image_url): ?>
                <img src="<?php echo e(asset($store->image_url)); ?>" alt="Store Image" class="img-fluid">
            <?php else: ?>
                <img src="https://via.placeholder.com/600" alt="No Image Available" class="img-fluid">
            <?php endif; ?>
        </div>
        <div class="col-md-6">
            <h2><?php echo e($store->title); ?></h2>
            <p><?php echo e($store->description); ?></p>
            <p><strong>Đơn vị tính:</strong> <?php echo e($store->unit); ?></p>
            <p><strong>Xuất xứ:</strong> <?php echo e($store->origin); ?></p>
            <p><strong>Địa chỉ:</strong> <?php echo e($store->address); ?></p>
            <p><strong>Giá bán:</strong> 
                <?php if($store->is_free): ?>
                    Miễn phí
                <?php else: ?>
                    <?php echo e(number_format($store->price, 0, ',', '.')); ?> đồng
                <?php endif; ?>
            </p>
            <div class="mt-4">
                <form action="<?php echo e(route('cart.add', ['store' => $store->id])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($store->id); ?>">
                    <label for="quantity">Số lượng:</label>
                    <input type="number" name="quantity" id="quantity" value="1" min="1" class="form-control mb-2" style="width: 100px;">
                    <button type="submit" class="btn btn-primary">Thêm vào giỏ hàng</button>
                </form>                
                <br>
                <button class="btn btn-success">Mua ngay</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shopc2c\resources\views/store/show.blade.php ENDPATH**/ ?>