<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Section-->
<section class="py-5">
    <div class="container px-4 px-lg-5 mt-5">
        <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
            <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col mb-5">
                <div class="card h-100">
                    <!-- Store image-->
                    <img class="card-img-top" src="<?php echo e(asset($store->image_url)); ?>" alt="Store Image" />
                    <!-- Store details-->
                    <div class="card-body p-4">
                        <div class="text-center">
                            <!-- Store title-->
                            <h5 class="fw-bolder"><?php echo e($store->title); ?></h5>
                            <!-- Store price-->
                            <?php if($store->is_free): ?>
                                <span>Cho tặng</span>
                            <?php else: ?>
                                <span>Giá: <?php echo e(number_format($store->price, 0, ',', '.')); ?> đồng</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!-- Store actions-->
                    <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                        <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="<?php echo e(route('store.show', $store->id)); ?>">Xem chi tiết</a></div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <!-- Pagination links -->
        <div class="d-flex justify-content-center mt-4">
            <?php echo e($stores->links('pagination::bootstrap-4')); ?>

        </div>
    </div>

    <style>
        .card-img-top {
            height: 250px; 
            object-fit: cover; 
        }
        .pagination {
            margin-top: 20px;
        }
    </style>
</section>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shopc2c\resources\views/store/index.blade.php ENDPATH**/ ?>